import LP.frmPrincipal;

/**
 * 
 */

/**
 * @author javier.cerro
 *
 */
public class clsMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		frmPrincipal p = new frmPrincipal();
		

	}

}
